<?php
require_once(dirname(dirname(__FILE__)) . '/modextraitem.class.php');

class modExtraItem_mysql extends modExtraItem
{
}