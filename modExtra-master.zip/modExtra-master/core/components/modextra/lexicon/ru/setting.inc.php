<?php

$_lang['area_modextra_main'] = 'Основные';

$_lang['setting_modextra_some_setting'] = 'Какая-то настройка';
$_lang['setting_modextra_some_setting_desc'] = 'Это описание для какой-то настройки';